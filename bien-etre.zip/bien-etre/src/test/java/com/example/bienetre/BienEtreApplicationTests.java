package com.example.bienetre;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BienEtreApplicationTests {

	@Test
	void contextLoads() {
	}

}
