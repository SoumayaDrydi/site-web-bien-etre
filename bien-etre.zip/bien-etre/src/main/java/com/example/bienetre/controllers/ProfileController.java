package com.example.bienetre.controllers;


import java.text.ParseException;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.bienetre.DAO.ProfileRepository;
import com.example.bienetre.entities.Profile;




@Controller
public class ProfileController {
	@Autowired
	ProfileRepository ProfileServer;
	@GetMapping("/")
public String register(Model model) {
		Profile profile=new Profile();
		model.addAttribute("profile", profile);
	return "register";
}
	@PostMapping("/saveProfile")
	public String saveProfile(@ModelAttribute("profilr") Profile profile,
	                          ModelMap modelMap) throws ParseException {
	   
	        Profile saveProfile = ProfileServer.save(profile);
	        String msg = "Produit enregistré avec Id " + saveProfile.getIDProf();
	        modelMap.addAttribute("msg", msg);
	    
	     

	    return "register";
	}
	@PostMapping("/registerUser")
	public String registerUser(@ModelAttribute("profile")Profile profile) {
		System.out.println(profile);
		return "home";
	}
	}

