package com.example.bienetre.service;

import org.springframework.stereotype.Service;

import com.example.bienetre.entities.Profile;

@Service
public interface ProfileServer {
	Profile saveProfile(Profile p);
 void registerProfile(Profile profile) ;
}
