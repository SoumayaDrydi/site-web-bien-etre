package com.example.bienetre.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.bienetre.entities.Profile;
@Repository

public interface ProfileRepository extends JpaRepository<Profile, Long>  {

}
