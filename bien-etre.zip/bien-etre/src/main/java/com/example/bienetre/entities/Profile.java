package com.example.bienetre.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Profile")
public class Profile {
@Id
private long IDProf;
private String nom;
private String prenom;
private int age;
private String sexe;
private float Taille;
private float poids;
private String description;
private float IMC =0;
private float MasseGrasse=0;
private float MasseMaigre=0;

public long getIDProf() {
	return IDProf;
}
public void setIDProf(long iDProf) {
	IDProf = iDProf;
}
public String getNom() {
	return nom;
}
public void setNom(String nom) {
	this.nom = nom;
}
public String getPrenom() {
	return prenom;
}
public void setPrenom(String prenom) {
	this.prenom = prenom;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getSexe() {
	return sexe;
}
public void setSexe(String sexe) {
	this.sexe = sexe;
}
public float getTaille() {
	return Taille;
}
public void setTaille(float taille) {
	Taille = taille;
}
public float getPoids() {
	return poids;
}
public void setPoids(float poids) {
	this.poids = poids;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public float getIMC() {
	return IMC;
}
public void setIMC(float iMC) {
	IMC = iMC;
}
public float getMasseGrasse() {
	return MasseGrasse;
}
public void setMasseGrasse(float masseGrasse) {
	MasseGrasse = masseGrasse;
}
public float getMasseMaigre() {
	return MasseMaigre;
}
public void setMasseMaigre(float masseMaigre) {
	MasseMaigre = masseMaigre;
}
public Profile() {
	super();
}

}
