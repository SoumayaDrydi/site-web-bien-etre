package com.iset.bienetre.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.bienetre.DAO.ProfileRepository;
import com.example.bienetre.entities.Profile;
import com.example.bienetre.service.ProfileServer;


public class ProfileServiceImpl implements ProfileServer{
	@Autowired
private ProfileRepository Profilerp;
@Override
public void registerProfile(Profile profile) {
	Profilerp.save(profile);
}
	@Override
	public Profile saveProfile(Profile p) { 
	 return  Profilerp.save(p); 
	 
}
}
