package com.iset.sante.controllers;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.iset.sante.model.ImcReponse;
import com.iset.sante.model.ImcRequest;
@RestController
public class ImcController {

	



	@RestController
	public class BmiController {

	    @PostMapping("/imc")
	    public ImcReponse calculateimc(@RequestBody ImcRequest request) {
	        double imc= calculateimc(request.getpoids(),request.gettaille());
	        String category;

	        if (imc < 18.5) {
	            category = "Underweight";
	        } else if (imc< 25) {
	            category = "Normal";
	        } else if (imc < 30) {
	            category = "Overweight";
	        } else {
	            category = "Obese";
	        }

	        return new ImcReponse(category, imc);
	    }

	    private double calculateimc (double poids, double taille) {
	        double imc = poids / Math.pow(taille / 100, 2);
	        return Math.round(imc * 100.0) / 100.0;
	    }
	}
}
