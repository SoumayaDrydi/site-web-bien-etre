package com.iset.sante.entities;

import java.util.Collection;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;

@Entity
public class Profil {
	
	
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY) 
	private int idprofil; 
	private String nom; 
	private String prenom;
	private int age;
	private String sexe; 
	private float taille ;
	private float poids ;
	private String description ;
	public Profil() {} 
	public Profil(int idprofil, String nom, String prenom, int age, String sexe, float taille, String description ,float poids ) {
		super();
		this.idprofil = idprofil;
		this.nom = nom;
		this.prenom = prenom;
		this.age = age;
		this.sexe = sexe;
		this.taille = taille;
		this.description = description;
		this.setPoids(poids);
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSexe() {
		return sexe;
	}
	public void setSexe(String sexe) {
		this.sexe = sexe;
	}
	public float getTaille() {
		return taille;
	}
	public void setTaille(float taille) {
		this.taille = taille;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public float getPoids() {
		return poids;
	}
	public void setPoids(float poids) {
		this.poids = poids;
	}
	@ManyToMany
	@JoinTable(
			name="profil_regime",
			joinColumns =@JoinColumn(name="idprofil"),
			inverseJoinColumns =@JoinColumn(name="idregime"))
	Collection<Regime>regime;
	
	@ManyToMany(mappedBy="profil")

	Collection<Activite> activite;

@ManyToOne
@JoinColumn(name="idcommunication",nullable=false)
private Communication communication;
} 

	
	

