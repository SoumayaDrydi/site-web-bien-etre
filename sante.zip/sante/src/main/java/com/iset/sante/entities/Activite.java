package com.iset.sante.entities;

import java.util.Collection;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;

@Entity
public class Activite {
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY) 
	private int idActivite;
	private String typeActivite;
	public Activite() {}
	public Activite(int idActivite, String typeActivite) {
		super();
		this.setIdActivite(idActivite);
		this.setTypeActivite(typeActivite);
	}
	public int getIdActivite() {
		return idActivite;
	}
	public void setIdActivite(int idActivite) {
		this.idActivite = idActivite;
	}
	public String getTypeActivite() {
		return typeActivite;
	}
	public void setTypeActivite(String typeActivite) {
		this.typeActivite = typeActivite;
	}
	@ManyToMany
	@JoinTable(
			name="profil_Activite",
			joinColumns =@JoinColumn(name="idActivite"),
			inverseJoinColumns =@JoinColumn(name="idprofil"))
	Collection<Profil>profil;

}
