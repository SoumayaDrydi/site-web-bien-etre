package com.iset.sante;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SanteApplication {

	public static void main(String[] args) {
		SpringApplication.run(SanteApplication.class, args);
	}

}
