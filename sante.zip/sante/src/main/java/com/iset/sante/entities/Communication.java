package com.iset.sante.entities;





import java.util.Set;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Communication {
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY) 
	private int idcommunication;
	private String avis_personnel;
	public Communication() {}
	public Communication(int idcommunication, String avis_personnel) {
		super();
		this.idcommunication = idcommunication;
		this.avis_personnel = avis_personnel;
	}
	public String getAvis_personnel() {
		return avis_personnel;
	}
	public void setAvis_personnel(String avis_personnel) {
		this.avis_personnel = avis_personnel;
	}
	@OneToMany(mappedBy="communication")
	private Set<Profil> profil;
	

}
