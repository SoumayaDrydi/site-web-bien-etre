package com.iset.sante.service;

public interface ProfilService {

}
